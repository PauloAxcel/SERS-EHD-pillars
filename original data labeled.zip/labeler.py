#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 15 18:35:18 2021

@author: newuser
"""

import pandas as pd

df = pd.read_csv(r'/home/newuser/Desktop/emily try/fullexcel.csv')
clean_df = df.dropna(axis=1,how='all').dropna(axis=0)

imagefile = r'/home/newuser/Desktop/emily try/Data2(part1+part3+part4+part6)/original data together/'

import os

images = os.listdir(imagefile)


import shutil

final_dir = r'/home/newuser/Desktop/emily try/Data3/original data labeled/'

for p in range(clean_df.shape[0]):
    label = int(clean_df['Label'].iloc[p])
    
    if label == 0:
        new_label = 'NONSERS'
    else:
        new_label = 'SERS'
    
    for i in images:    
        part =  int(i.split('.')[0])
        pillar =  int(i.split('.')[1])
        
        if part == int(clean_df['part'].iloc[p]) and pillar == int(clean_df['map point'].iloc[p]):
            new_name = str(part)+'.'+str(pillar)+'.'+new_label+'.png'
            os.rename(imagefile+i, final_dir+new_name)
            
            




